Fixed and verified in the editor: bashing an invulnerable junkdog during its lunge or jump attack now ends the attack, and that attack no longer hits the player. Result is `pass`.

**Cause:** a bash only stopped a junkdog's attack because it deals damage. Invulnerability sets that damage to 0, so the attack kept going and still hit the player (`DamageHandler.cs:141-155`). The jump attack has no other way to be cancelled while the junkdog is in the air.

**Fix:** in `Assets/Scripts/Combat/Entities/Bots/JunkDog/JunkDogAI.cs`, a bash that lands during an attack now cancels it by itself. This applies to both the jump and the lunge. The bash is still blocked: no damage, no stun, and one invulnerability shield is used up. Junkdogs without invulnerability already stopped on a bash through its damage, so they behave as before.

**Verification:** I set the case up from code on Quick Rampage, sent a bash the moment the attack began, and logged every junkdog hit on the player.
- **Lunge, plain Junkdog (4 runs):** the bash was blocked each time and the attack ended within 10 frames. None of the bashed attacks hit the player.
- **Jump attack, plain Junkdog (2 runs, jump forced):** same result.
- **Regression, Spiked and Bloodhound with invulnerability, bashed mid-jump:** blocked, no hit from that attack.
- **Control:** attacks I didn't bash still hit the player, and a bash on a junkdog without invulnerability still dealt damage and stopped the attack.
- **Console and captures:** 0 errors; 17 screenshots, and the capture check passed.

**Caveats:**
- I couldn't show the lunge failing at runtime before the fix. The jump-attack cause is from reading the code. The lunge also has an impact-based cancel that the first video shows didn't stop the hit, and I didn't confirm why. The new check covers the lunge either way.
- In my first run, before the hit logger existed, the player lost 38 HP in the 7 seconds after the bash. Later logged runs only showed hits from the junkdog's next attacks, so this was most likely a later attack, but that run wasn't logged.
- Cerberus, Dozer, Jack, Mantis, Roach and Ussam also stop their attacks only on damage, so they probably have the same gap. I left them alone because the card names only junkdogs.
- Armored, Turbo, Rabid and the other Junkdog variants weren't tested one by one. They run the same `JunkDogAI` code that was changed.

The PR description, result JSON and progress journal are written. The working tree holds only the `JunkDogAI.cs` change plus the run's own files.