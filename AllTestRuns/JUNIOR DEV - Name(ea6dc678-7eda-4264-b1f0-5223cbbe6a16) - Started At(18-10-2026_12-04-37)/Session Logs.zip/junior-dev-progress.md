title: Invulnerable junkdog still hits player when bashed
result: pass
phase: done
updated: 12:23:10 (+18m)

[12:05:04 +00m] started - source branch master, task: bashing an attacking junkdog while it has invulnerability still hits the player (also on jump attacks); branch ok, only untracked junior-dev-full-process-debug.jsonl (workflow file)
[12:09:43 +04m] oriented - singleplayer: card label SinglePlayer, SP JunkDogAI; job bug: card labeled Bug, existing behaviour that should not happen
[12:09:43 +04m] reported case - player bashes (BashGuard) a junkdog with invulnerability stacks during its lunge (vid1) or jump attack (vid2): the attack still damages the player; expected: the bash cancels the attack as it does on a junkdog without invulnerability (that case works)
[12:09:43 +04m] cause - DamageHandler.cs:141-155 zeroes the bash damage on an invulnerable entity (Blocked, spends a stack); JunkDogAI.cs:661/696 cancel the attack only via CancelIfReceivingDamage (damage > 0), so the attack scope keeps running, isAttacking stays true (:736/:776) and collisionDamageBehavior (:233) hits the player. Jump path has no other cancel; lunge's impact cancel (:720) evidently does not save it per vid1 | plan - JunkDogAI.cs: cancel JumpAttack/LungeAttack when an incoming Bash interaction arrived since the attack started, reusing main.CancelIf + OnAttackEnd; QA: invulnerable junkdog, bash during jump and lunge, player health unchanged
[12:11:30 +06m] implemented - JunkDogAI.cs: WasBashedDuringAttack() (incoming Bash-tagged interaction since latestAttackAttempt.startFrame), registered as main.CancelIf(..., OnAttackEnd) in JumpAttack and LungeAttack
[12:11:30 +06m] compiled - clean (editor ready, no preexisting errors)
[12:14:21 +09m] verifying - /qa inline, singleplayer, configs Dev/No VR, PC Room Segregation, Quick Rampage, Dont Spawn Enemies, No Death (instead of God, so the junkdog's hit on the player shows as health loss)
[12:14:21 +09m] play - Quick Rampage ready
[12:19:10 +14m] runs - Junkdog Normal with invulnerability (FirstHitBlockCombatEvent source), bash sent from the mech's BashGuard (CreateBashInteraction) the frame the attack's isAttacking turned on: 4 lunge + 1 forced jump (forcedAttackType) runs - each bash Blocked (dmg 0, stack spent), isAttacking false within 10 frames, no junkdog->mech hit from the bashed attempt (hit log keyed by attempt start frame); un-bashed attacks between runs did hit the mech (CollisionDamageBehavior), ~3 s apart. Control without invulnerability: bash dealt 20 dmg, cancelled as before. Run 1 showed -38 player HP in the 280 frames after the bash with no per-hit log yet; later logged runs show those hits come from the next attempts
[12:22:08 +17m] regression - Junkdog Spiked and Bloodhound with invulnerability, each bashed mid jump attack: Blocked, no hit on the mech from that attempt (Bloodhound last outgoing hit before its bash; Spiked next hit ~12 s later)
[12:22:08 +17m] captures - 7 isolated-close, 5 regression-check, 5 non-isolated-wide: checked ones show Bloodhound/Spiked with the blue-violet invulnerable bar and shield icons in the Quick Rampage arena; check-captures OK; console 0 errors; exited play
[12:23:10 +18m] done - PR file and result written: pass
