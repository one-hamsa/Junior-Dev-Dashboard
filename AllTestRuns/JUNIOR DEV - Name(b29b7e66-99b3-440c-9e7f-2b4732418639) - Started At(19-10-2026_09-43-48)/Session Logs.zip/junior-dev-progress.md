title: Haptics stuck on forever after losing an arm
result: inconclusive
phase: done
updated: 10:18:17 (+33m)

[09:44:19 +00m] started - source branch master, task: you can get haptic forever sometimes when you lose your arm
[09:48:11 +03m] oriented - multiplayer: MP_ mech is the live player mech and singleplayer code is frozen (code-style.md Boundaries); job bug: card says haptics get stuck, JOB TYPE BUG FIX
[09:48:11 +03m] reported case - player mech loses an arm (any cause), sometimes the controller on that side keeps pulsing haptics forever; expected: haptics stop. Readings: (a) a per-arm haptic sender keeps running after arm death; (b) a held-prop sender keeps running. Held props ruled out in code: Detach -> ReleaseHeldPropGrab clears _holderInput (MP_HeldPropEntity.cs:585)
[09:48:11 +03m] cause - MP_HandIKFollower.cs:390 LimitedArmHapticsCo loops while state == VelocityLimited, pulsing 0.5 every 0.2s; the state only leaves VelocityLimited in UpdateLimitVelocity via LazyFollow, which MP_MechArmRig.UpdateForPhysics (:542) skips once IsAttached (=isAlive) is false. Arm dies during a punch/recoil slowdown -> state stuck, coroutine keeps running on the debris arm, which lives until the mech dies (GenerateMainDebris AddDependantEntity). "Sometimes" = only when killed inside the slowdown window | plan - end the loop when mechArm.isAlive is false; QA: kill an arm while velocity limited and check coroutine stops (state + haptic calls)
[09:48:49 +04m] implemented - MP_HandIKFollower.cs: LimitedArmHapticsCo loop also requires mechArm.isAlive
[10:17:14 +32m] editor - three unity_ready waits (600s, 540s, 480s) all returned loading with no dialogs; out of budget, no compile and no QA
[10:17:45 +33m] report - PR file written with unverified state stated
[10:18:17 +33m] done - result inconclusive
