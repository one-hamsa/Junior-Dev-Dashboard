I found a likely cause and made a one-line fix, but it hasn't been compiled or tested. The Unity editor was still loading after about 27 minutes of waiting, so I ran out of budget before compiling or running QA. The result is **inconclusive**.

**Cause (from reading the code):**
- After a punch hit or a weapon recoil, the arm briefly slows down. During that slowdown a loop in `MP_HandIKFollower.LimitedArmHapticsCo` pulses that side's controller every 0.2 s.
- The slowdown only ends through the arm's per-frame follow update, and that update stops running once the arm is dead.
- So if the arm is lost during the slowdown, the slowdown never ends and the pulsing carries on until the mech itself dies. The arm's debris stays active until then, so the loop keeps running.
- This explains "sometimes": the arm has to be lost inside that short window after a hit or recoil.
- Held props (buzz saw, grappling hook) are not the cause: losing the arm releases the prop, which stops their haptics.

**Fix:** In `Assets/__Multiplayer/Scripts/Mech/MP_HandIKFollower.cs`, the loop now also stops when the arm is dead (`while (state == State.VelocityLimited && mechArm.isAlive)`).

**Not done:**
- **Singleplayer:** `SP_HandIKFollower.cs` has the same loop. I left it alone because the project guides mark singleplayer code as frozen. If singleplayer needs it, it's the same one-line change.
- **Hand test:** punch with an arm (or fire a recoil weapon), get that arm destroyed right after the hit, and check that the controller stops buzzing right away.

I wrote the PR description, the result JSON and the progress journal to the requested paths.