title: Main menu mech missing arm and looping SFX after level
result: aborted
phase: done
updated: 13:00:11 (+27m)

[12:33:16 +00m] started - source branch master, task: after a sandbox level or challenge, back in main menu the mech misses an arm and an SFX loops
[12:39:28 +06m] oriented - singleplayer: card label SinglePlayer, main menu + sandbox/challenge are SP flow; job bug: card labeled Bug, existing visual broken after a scene return
[12:39:28 +06m] reported case - main menu mech (Main Menu.unity, Killing Arm / Saw Arm objects under state "Killing Hand") after entering any sandboxxer level or challenge and exiting to main menu (PauseMenu.OnExitToMainMenu -> GameManager.Restart): one arm missing + a looping SFX; should be: full mech, no loop. Works: first boot into main menu. Readings: arm object deactivated vs destroyed vs moved; SFX from the arm or from a leftover sandbox object. Commit c302f4b936 (MPActivatorBase.OnEnable UpdateState) is a card hint, not established
[12:39:28 +06m] runtime check - question: after booting into Sandbox and GameManager.Restart back to main menu, which main-menu mech arm objects are inactive/missing and which AudioSources are playing looped?
[12:59:22 +26m] runtime check - not answered: booted into Sandbox (Play) fine, but GameManager.Restart re-ran the sandbox debug meta graph (Sandbox, then The Killbox); removing the config + FullDebugRestart landed in SUS, and Singleplayer from SUS went into the new-save intro (Expo - COLOR) because the config disables save auto-loading. Never reached Main Menu; exited play, configs cleared
[13:00:11 +27m] done - aborted, cause not found for both problems; no code changed, no PR file
