I stopped without fixing anything because I couldn't find the cause of either problem: the missing arm or the looping sound. No code was changed and there's no PR file. The result JSON is written with `aborted` / `cause not found`.

**Why the attached commit doesn't explain it:** c302f4b936 only changes `MPActivatorBase.OnEnable`, and no `MPActivator` is placed in the main menu scene. In singleplayer that call switches things off exactly as it already did before the commit, just earlier.

**Live check (didn't get there):** the plan was to enter Sandbox, exit to the main menu, and see which arm object is off and which sound is still playing.
- **Sandbox debug config:** exiting to the main menu just sent me back into the sandbox, then into The Killbox.
- **Without that config:** a debug restart opened a new save's intro cutscene instead of the main menu.

I left Play mode and turned the debug configs back off.

**Leads for the next attempt (not confirmed):**
- **The arm:** the menu mech is a flat image with two arm objects in `Main Menu.unity`, "Killing Arm" and the alternative "Killing Arm Balls". The main menu step in `SINGLEPLAYER Graph.asset` shows one or the other through the "Killing Hand" and "Balls Hand" states, from one yes/no value and its opposite. The first thing to check is whether both end up off after a challenge.
- **The sound:** I found nothing in the code for it. Commit 8c06dce06d (pooled damage effects that kept looping, arm attachments) is the only lead, and I didn't check it.

**Next steps:**
- Run a follow-up session that starts in the main menu on an existing save ("Advanced/Flow/Start In Main Menu" with save loading on). It should enter a challenge through the menu, exit, and then check the two arm objects and which audio events are still playing.
- Or, if someone can reproduce it, they can check those same two arm objects and the playing sound directly after returning to the main menu.