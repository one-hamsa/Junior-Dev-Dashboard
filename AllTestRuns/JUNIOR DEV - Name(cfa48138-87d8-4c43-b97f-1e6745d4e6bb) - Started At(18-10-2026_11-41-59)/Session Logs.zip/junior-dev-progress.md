title: Hands stretch to random place after app focus loss
result: inconclusive
phase: done
updated: 11:54:52 (+12m)

[11:42:32 +00m] started - source branch master, task: hands stretch to a random place after pressing the Meta button / app losing focus (PVP)
[11:50:52 +08m] oriented - multiplayer: card has PVP label, SP pauses time on focus loss (TimeScaleManager.Set skipped in MP); job bug: hands stretch instead of staying put
[11:50:52 +08m] reported case - Quest, in a multiplayer match, press Meta button (app loses focus): mech hands stretch to some point instead of holding last pose; should hold last pose; every time focus is lost
[11:50:52 +08m] cause - OVRCameraRig.cs:376-409 (Meta XR SDK): with no active controller (focus lost) GetLocalControllerPosition(None) returns Vector3.zero, written to LeftHandAnchor/RightHandAnchor = Heirarchy.handL/handR (Oculus Root Variant.prefab), so mech arms reach for the tracking-space origin. SP hides it via AppFocusManager time scale 0; MP does not pause (TimeScaleManager.cs:18) and nothing holds the hand pose | plan - VRPlugin_Oculus.OnAnchorsUpdated: store hand anchor local poses while HasFocus, re-apply them while unfocused; QA: editor cannot lose Meta focus - inconclusive expected, compile + MP regression look
[11:51:10 +09m] implemented - VRPlugin_Oculus.cs: HoldHandAnchorsWhileUnfocused called from OnAnchorsUpdated
[11:51:26 +09m] editor - ready, no compile errors before the change
[11:53:43 +11m] compiled - clean (first compile request hit a bridge deadline, retried)
[11:54:52 +12m] verifying - skipped /qa: change runs only under VRPlugin_Oculus (Meta headset); cloud editor runs the Manual plugin, no editor run reaches the code or can raise Meta focus loss
[11:54:52 +12m] done - PR file and result written, inconclusive
